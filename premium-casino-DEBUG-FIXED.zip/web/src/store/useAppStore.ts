import { create } from 'zustand'
import { AppState, User, CasinoConfig, Transaction, UIUpdate } from '@/types'
import { showNotification } from '@mantine/notifications'

interface AppStore extends AppState {
  // Actions
  setUser: (user: User | null) => void
  setConfig: (config: CasinoConfig) => void
  setCurrentPage: (page: string) => void
  setLoading: (loading: boolean) => void
  setError: (error: string | null) => void
  updateBalance: (balance: number) => void
  initialize: (data: any) => void
  handleUIUpdate: (update: UIUpdate) => void
  
  // Game-specific state
  transactions: Transaction[]
  setTransactions: (transactions: Transaction[]) => void
  
  // NUI Communication
  sendNUIMessage: (action: string, data?: any) => Promise<any>
}

// Get resource name helper
const GetParentResourceName = (): string => {
  // @ts-ignore - FiveM NUI function
  return window.GetParentResourceName ? window.GetParentResourceName() : 'casino'
}

// NUI Communication helper
const sendNUIMessage = async (action: string, data?: any): Promise<any> => {
  return new Promise((resolve, reject) => {
    try {
      // Check if we're in a proper NUI context
      // @ts-ignore - FiveM NUI functions
      if (typeof window.invokeNative === 'undefined' && typeof window.GetParentResourceName === 'undefined') {
        console.log('Not in NUI context, skipping callback')
        reject(new Error('Not in NUI context'))
        return
      }

      // @ts-ignore - NUI callback function
      fetch(`https://${GetParentResourceName()}/${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data || {}),
      })
        .then(response => response.json())
        .then(resolve)
        .catch(reject)
    } catch (error) {
      reject(error)
    }
  })
}

export const useAppStore = create<AppStore>((set, get) => ({
  // Initial state
  isInitialized: false,
  user: null,
  config: null,
  currentPage: 'lobby',
  isLoading: false,
  error: null,
  transactions: [],

  // Actions
  setUser: (user) => set({ user }),
  
  setConfig: (config) => set({ config }),
  
  setCurrentPage: (page) => set({ currentPage: page }),
  
  setLoading: (loading) => set({ isLoading: loading }),
  
  setError: (error) => {
    set({ error })
    if (error) {
      showNotification({
        title: 'Error',
        message: error,
        color: 'red',
      })
    }
  },
  
  updateBalance: (balance) => {
    const { user } = get()
    if (user) {
      set({ user: { ...user, balance } })
    }
  },
  
  initialize: (data) => {
    console.log('Initialize called with data:', data)
    console.log('Config received:', data.config)
    console.log('User received:', data.user)
    set({
      config: data.config,
      user: data.user,
      isInitialized: true,
      currentPage: data.user ? 'lobby' : 'auth',
    })
    console.log('App state after initialize:', { 
      isInitialized: true, 
      hasConfig: !!data.config, 
      hasUser: !!data.user,
      currentPage: data.user ? 'lobby' : 'auth'
    })
  },
  
  setTransactions: (transactions) => set({ transactions }),
  
  handleUIUpdate: (update) => {
    const { user } = get()
    
    switch (update.action) {
      case 'initialize_app':
      case 'initializeApp':
        console.log('Initializing app with server config:', update.config)
        console.log('Full update object:', update)
        set({ 
          config: update.config,
          isInitialized: true,
          currentPage: 'auth' // Default to auth page until user data is received
        })
        console.log('App initialized via handleUIUpdate')
        break
        
      case 'show_auth':
        console.log('Server requesting to show auth page')
        set({ 
          currentPage: 'auth',
          isInitialized: true
        })
        break
        
      case 'login_success':
        console.log('Login successful, updating store...', update.user)
        set({ 
          user: update.user,
          currentPage: 'lobby',
          error: null,
          isLoading: false,  // Clear loading state
          isInitialized: true  // Ensure app is marked as initialized on login
        })
        showNotification({
          title: 'Welcome!',
          message: `Logged in as ${update.user.username}`,
          color: 'green',
        })
        break
        
      case 'login_failed':
        console.log('Login failed:', update.message)
        set({ 
          error: update.message,
          isLoading: false  // Clear loading state
        })
        showNotification({
          title: 'Login Failed',
          message: update.message || 'Invalid username or password',
          color: 'red',
        })
        break
        
      case 'registration_success':
        showNotification({
          title: 'Success!',
          message: 'Account created successfully. You can now log in.',
          color: 'green',
        })
        break
        
      case 'logout_success':
        set({ 
          user: null,
          currentPage: 'auth',
          transactions: []
        })
        showNotification({
          title: 'Goodbye!',
          message: 'You have been logged out.',
          color: 'blue',
        })
        break
        
      case 'balance_updated':
        if (user) {
          set({ user: { ...user, balance: update.balance } })
        }
        break
        
      case 'transactions_loaded':
        set({ transactions: update.transactions })
        break
        
      case 'session_expired':
        set({ 
          user: null,
          currentPage: 'auth',
          error: 'Your session has expired. Please log in again.'
        })
        break
        
      case 'slots_result':
        // Handle slot result (will be processed by slot component)
        if (update.outcome.isWin) {
          showNotification({
            title: 'Winner!',
            message: `You won $${update.outcome.payout.toFixed(2)}!`,
            color: 'green',
          })
        }
        if (user) {
          set({ user: { ...user, balance: update.balance } })
        }
        break
        
      case 'plinko_result':
        // Handle plinko result
        if (update.outcome.payout > update.outcome.betAmount) {
          showNotification({
            title: 'Winner!',
            message: `You won $${update.outcome.payout.toFixed(2)}!`,
            color: 'green',
          })
        }
        if (user) {
          set({ user: { ...user, balance: update.balance } })
        }
        break
        
      case 'aviator_round_start':
        // Handle aviator round start
        break
        
      case 'aviator_update':
        // Handle aviator state update
        break
        
      case 'aviator_crashed':
        // Handle aviator crash
        showNotification({
          title: 'Crashed!',
          message: `Multiplier crashed at ${update.crashMultiplier.toFixed(2)}x`,
          color: 'red',
        })
        break
        
      default:
        console.log('Unhandled UI update:', update)
    }
  },
  
  sendNUIMessage,
}))

// NUI Event Listener Setup
if (typeof window !== 'undefined') {
  window.addEventListener('message', (event) => {
    console.log('Raw NUI message received:', event.data)
    
    if (!event.data || typeof event.data !== 'object') {
      console.log('Invalid NUI message format:', event.data)
      return
    }
    
    const { type, data } = event.data
    
    if (!type) {
      console.log('Missing type in NUI message:', event.data)
      return
    }
    
    switch (type) {
      case 'openApp':
      case 'initializeApp':
        console.log('Initializing app with data:', data)
        useAppStore.getState().initialize(data)
        break
        
      case 'updateUI':
        console.log('Updating UI with data:', JSON.stringify(data, null, 2))
        // Handle special initializeApp action within updateUI
        if (data.action === 'initializeApp') {
          console.log('Processing initializeApp from updateUI:', data)
          useAppStore.getState().initialize({
            config: data.config,
            user: data.user,
            events: data.events
          })
        } else {
          console.log('Processing action:', data.action)
          useAppStore.getState().handleUIUpdate(data)
        }
        break
        
      case 'closeApp':
        // Handle app close if needed
        break
        
      default:
        console.log('Unknown NUI message type:', type, 'Full message:', event.data)
    }
  })
  
  // ESC key handling is managed by fd_laptop
}